function [letters, histogram]=facilities_histogram(route)
    % In this for loop we fill "letters" vector with unique letters from
    % the route
    letters = [];
    for facility_index=1:length(route)
        facility = route(facility_index);

        is_letter_already_in_letters = false; 

        for letter=letters
            if letter == facility
                is_letter_already_in_letters = true;
            end
        end

        if ~is_letter_already_in_letters
            letters = [letters, facility];
        end
    end
    
    % In this for loop we fill new "numeric_route" vector, where letters
    % replaced with numbers.
    numeric_route = zeros(size(route));
    
    for facility_index=1:length(route)
        facility = route(facility_index);
        for letter_index=1:length(letters)
            current_letter = letters(letter_index);
            
            if current_letter == facility
                numeric_route(facility_index) = letter_index;
            end
        end
    end
    
    % Create new histogram vector with the same size as letters vector
    histogram = zeros(1, length(letters));
    
    % In this for loop we create histogram of our facilities
    for facility=numeric_route 
        histogram(facility) = histogram(facility) + 1; 
    end
end