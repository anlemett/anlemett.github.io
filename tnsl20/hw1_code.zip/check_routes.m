[letters1, histogram1] = facilities_histogram('ABCBAC');
[letters2, histogram2] = facilities_histogram('CCAABB');

% Unless we found that we for some facility we have not equivalent number
% of entries, we assume that our route is good
is_new_route_equivalent = true;

% In this for loop we iterate through all letters in "letters1"
for letter_index_1=1:length(letters1)
    letter_from_1 = letters1(letter_index_1);
    
    % In this loop we iterate through all letters in "letters2"
    for letter_index_2=1:length(letters2)
        letter_from_2 = letters2(letter_index_2);
        
        % If we have equivalent letters, then we should check corresponding
        % values of histogram
        if letter_from_1 == letter_from_2
            if ~(histogram1(letter_index_1) == histogram2(letter_index_2))
                is_new_route_equivalent = false;
            end
        end
    end
end


if is_new_route_equivalent
    disp('New route is good!')
else
    disp('New route is bad!')
end