clear;
v = 0:4:1000;

% disp(v);
disp('Value of the 76th element of v is: ');
disp(v(76));


disp('Value of the 25th element of v before change is: ');
disp(v(25));
v(25)= v(25)-1;
disp('Value of the 25th element of v after change is: ');
disp(v(25));

disp('Element of v with indices 25-45 are: ');
disp(v(24:45));


t = ones(1, 100) * 20;

disp('Vector t is:');
disp(t);