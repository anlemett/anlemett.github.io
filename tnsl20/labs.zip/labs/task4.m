clear;

v = [1, 10, 20];

for i=1:length(v)
    for j=1:length(v)
        disp([v(i), v(j)]);
    end
end