clear;

a = 0;

while a < 5
    disp('Hello World!');
    a = a + 1;
end